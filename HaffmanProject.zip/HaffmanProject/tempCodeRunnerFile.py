decom_path = h.decompress(output_path)
# print("Decompressed filpath: " + decom_path)