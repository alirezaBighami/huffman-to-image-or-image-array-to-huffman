import re
from tempfile import tempdir
import numpy as np
import heapq
import os
import sys
import json
import networkx as nx
import matplotlib.pyplot as plt
from collections import defaultdict

# programmed by alirezaZzz & javad

# from test import freq

class Huffman:
	def __init__(self, path):
		self.path = path
		self.heap = []
		self.codes = {}
		self.reverse_mapping = {}
		self.frequency = ""

	class HeapNode:
		# frequency
		def __init__(self, char, freq):
			self.right = None
			self.left = None
			self.char = char
			self.freq = freq

		def __eq__(self, other):
			if(other == None):
				return False
			if(not isinstance(other, HeapNode)):
				return False
			return self.freq == other.freq

		# defining comparators less_than and equals
		def __lt__(self, other):
			return self.freq < other.freq

 
 
	def frequencyDictMaker(self, text):
		#init list dict
		frequency={}
		#set arr same [32,43,12]
		numbers = re.findall("\d+", text)

		for num in numbers:
			if (not num in frequency):
				frequency[num] = 0
			frequency[num]+=1		
		print("frequency: ", frequency)
		return frequency
	
	def draw(node,data):   # Draw a node as root
		saw = defaultdict(int)

		def create_graph(G, node, p_name ="initvalue", pos={}, x=0, y=0, layer=1):
			if not node:
				return
			name = str(node.name)
			print("node.name:",name,"x,y:(",x,",",y,")l_layer:",layer)
			saw[name] += 1
			if name in saw.keys():
				name += ' ' * saw[name]
			if p_name != "initvalue" :
				G.add_edge(p_name, name)
			pos[name] = (x, y)			
			l_x, l_y = x - 1 / (3 * layer), y - 1
			#print("l_x, l_y:",l_x, l_y)
			l_layer = layer + 1
			#print("l_layer:",l_layer)
			create_graph(G, node.left, name, x=l_x, y=l_y, pos=pos, layer=l_layer)		
			r_x, r_y = x + 1 /( 3 * layer), y - 1
			#print("r_x, r_y:", r_x, r_y)
			r_layer = layer + 1
			create_graph(G, node.right,name, x=r_x, y=r_y, pos=pos, layer=r_layer)
			return (G, pos)

		graph = nx.DiGraph()
		graph.name
		graph, pos = create_graph(graph, node)
		#pos["     "] = (0, 0)
		print("pos:",pos)
		fig, ax = plt.subplots(figsize=(8, 10))  # Scale can be adjusted appropriately according to the depth of the tree
		color_map = []
		# for j,node in enumerate(graph.nodes):
		for degree in graph.out_degree:
			if int(degree[0]) in data and degree[1] == 0:
				color_map.append('blue')
			else:
				color_map.append('green')
		#nx.draw(G, node_color=color_map, with_labels=True)
		nx.draw_networkx(graph, pos, ax=ax, node_size=1000,node_color=color_map)
		plt.show()




	def mergeNodes(self):
		while(len(self.heap) > 1):
			node1 = heapq.heappop(self.heap)
			node2 = heapq.heappop(self.heap)

			merged = self.HeapNode(None, node1.freq + node2.freq)
			merged.left = node1
			merged.right = node2

			heapq.heappush(self.heap, merged)

	def writeEncodedText(self, text):
		encoded_text = ""
		#set arr same [32,32,32,32,32]
		te = re.findall("\d+",text)
		print("cods path: ./output_codes.txt")
		with open("output_codes.txt", "w") as txt_file:
			#write all keys in the file
			txt_file.write(json.dumps(self.codes))
         
		for character in te:
			encoded_text += self.codes[character]
		#show size 
		print("size of input  :"+str(len(te)*8))
		print("size of output :"+str(len(encoded_text)))
		print("size of diffrent :"+str((len(te)*8-len(encoded_text))))
		return encoded_text


	def makeCodes(self, root, current_code):
		if(root == None):
			return

		if(root.char != None):
			self.codes[root.char] = current_code
			self.reverse_mapping[current_code] = root.char
			return

		self.makeCodes(root.left, current_code + "0")
		self.makeCodes(root.right, current_code + "1")

	def codesMaker(self):
		root = heapq.heappop(self.heap)
		current_code = ""
		self.makeCodes(root, current_code)
	
	def heapMaker(self, frequency):
		for key in frequency:
			#create new node with key and value
			node = self.HeapNode(key, frequency[key])
			#push to new heap
			heapq.heappush(self.heap, node)



	#create binary text
	def padding(self, encodedText):
		extra_padding = 8 - len(encodedText) % 8
		for i in range(extra_padding):
			encodedText += "0"

		padded_info = "{0:08b}".format(extra_padding)
		encodedText = padded_info + encodedText
		return encodedText

	def get_byte_array(self, paddedEncodedText):
		if(len(paddedEncodedText) % 8 != 0):
			print("Encoded text not padded properly")
			exit(0)

		b = bytearray()
		for i in range(0, len(paddedEncodedText), 8):
			byte = paddedEncodedText[i:i+8]
			b.append(int(byte, 2))
		return b


	def compress(self):
		#seprate between format and name
		filename, file_extension = os.path.splitext(self.path)
		#create name file with bin format
		output_path = filename + ".bin"
		output_text_path = filename + "_text.txt"

		with open(self.path, 'r+') as file, open(output_path, 'wb') as output, open(output_text_path, 'w') as output_txt:
			text = file.read()
			#remove space 
			text = text.rstrip()

			self.frequency = self.frequencyDictMaker(text)

			self.heapMaker(self.frequency)
			self.mergeNodes()
			self.codesMaker()
			#create huffman code 
			encoded_text = self.writeEncodedText(text)
			padded_encoded_text = self.padding(encoded_text)
			b = self.get_byte_array(padded_encoded_text)
			output_txt.write(encoded_text)
			output.write(bytes(b))      


		print("Compressed")
		return output_path

	""" functions for convert huffman str to picture: """

	def createFrequencyArr(self, frequency_str):
		#init new dict arr
		frequency={}
		#cut all numbers from this string : for example: 32=>44 ,55=>143 convert to [32,44,55,143]
		numbers = re.findall("\d+", frequency_str)
		#make dict from numbers list
		for i in range(0, len(numbers)-1,2):
			frequency[numbers[i]]=numbers[i+1]

		return frequency
		


	def decompress(self, huffman_str , frequency ):
		numbers =""
		temp = ""
		# make string same => 12 232 13 453
		for char in huffman_str:
			temp += char
			for i in frequency:
				if frequency[i] == temp:
					numbers += i+" "
					temp=""
					continue
		return numbers
